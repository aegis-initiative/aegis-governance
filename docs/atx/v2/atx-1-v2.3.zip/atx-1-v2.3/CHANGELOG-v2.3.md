# 2026-04-24 — ATX-1 v2.3: Severity Field Removed for MITRE Alignment

**Date:** 2026-04-24\
**Type:** Version release\
**Status:** Published\
**Tag:** `atx-1-v2.3`\
**DOI:** Pending Zenodo deposit

---

## Summary

ATX-1 v2.3 removes the `severity` field from technique definitions to align with MITRE ATT&CK and ATLAS conventions, which leave contextual scoring (severity, impact, probability) to the consumer rather than embedding it in the taxonomy. Tactic, technique, sub-technique, root cause, and mitigation structure carries over unchanged from v2.2.

This change was made in response to peer feedback on the IEEE Data Descriptions submission (Reviewer 1 of Manuscript ID DATA-00033-2026), which observed that severity ratings in v2.2 reflected author judgment rather than a defensible quantitative risk model. Rather than develop a quantitative severity methodology, v2.3 adopts the convention used by both sister frameworks (ATT&CK and ATLAS): the taxonomy defines what failure modes exist and how they relate to controls, and downstream consumers attach context-specific severity in their own deployments.

---

### Removed

- **`severity` field** — Removed from all 58 entries in `atx-1-techniques.json` (29 parent techniques + 29 sub-techniques).
- **`severity` property** — Removed from `atx-technique.schema.json` `properties` block and from `required` array. Schema version bumped 2.2 → 2.3.
- **Severity ratings** — Removed from `ATX-1_TECHNIQUE_TAXONOMY.md` technique descriptions and from the severity-distribution section.
- **Severity badges and columns** — Removed from the public matrix UI (`aegis-docs/src/pages/matrix.astro`) and from the public matrix data pages (techniques.md, machine-readable.md).

### Unchanged

- **Tactics:** 10 (TA001–TA010), all carried over.
- **Techniques:** 29 parent techniques, all carried over.
- **Sub-techniques:** 29, all carried over.
- **Root causes:** 5 (RC1–RC5), all carried over.
- **Mitigations:** 29, all carried over.
- **STIX 2.1 bundle:** 204 objects (1 identity + 10 tactics + 58 attack-patterns + 29 mitigations + 106 relationships), no structural change — STIX never carried `severity` in attack-patterns.

### Compatibility

- v2.2 consumers that did not read `severity` are forward-compatible.
- v2.2 consumers that did read `severity` must either default to a constant (e.g., "unrated") or compute severity from their own context.
- The reverse mapping is documented in `docs/atx/v2/data/atx-1-version-mapping.json`.

### Rationale (extended)

MITRE ATT&CK does not assign severity at the technique level; ATLAS does not either. The reasoning common to both: a technique's severity depends on the asset it targets, the environment it operates in, and the controls already present. A taxonomy that embeds severity as a fixed attribute conflates the *what* (the failure mode) with the *how-bad-is-it* (the contextual risk), and forces every consumer to either trust the taxonomy author's judgment or override it. ATX-1 v2.3 follows MITRE precedent: the taxonomy describes structural failure modes; severity is a deployment-level concern.

This also closes the open-question raised in earlier ATX-1 versions about whether the author's severity assignments were calibrated against any quantitative model. The answer was that they were author judgments used for internal triage priority. Rather than retrofit a quantitative severity model, v2.3 removes the field and frees consumers to attach their own.

### Metrics

- **Tactics:** 10 (unchanged)
- **Techniques:** 29 parent + 29 sub-techniques (unchanged)
- **Root causes:** 5 (unchanged)
- **Mitigations:** 29 (unchanged)
- **STIX objects:** 204 (unchanged)
- **Severity field:** removed everywhere

### Files changed

- `docs/atx/v2/data/atx-1-techniques.json`
- `docs/atx/v2/schema/atx-technique.schema.json`
- `docs/atx/v2/data/atx-1-regulatory-crossref.json` (metadata only; entries unchanged)
- `docs/atx/v2/data/atx-1-navigator-layer.json` (metadata only)
- `docs/atx/v2/data/atx-1-atm1-mapping.json` (metadata only)
- `docs/atx/v2/atx-meta.json` (version bumped; v2.3 DOI fields pending)
- `docs/atx/v2/ATX-1_TECHNIQUE_TAXONOMY.md`
- `docs/atx/v2/README.md`
- `docs/atx/v2/data/atx-1-version-mapping.json` (v1.0-to-2.3 mapping added)
- aegis-docs site: `matrix.astro`, `techniques.md`, `index.md`, `tactics.md`, `machine-readable.md`

### Pending follow-ups

- Zenodo deposit (new version of existing record series).
- IEEE DataPort deposit.
- Update ecosystem CLAUDE.md identifier registry once v2.3 DOI mints.
- Update IEEE Data Descriptions descriptor revision (DATA-00033-2026) to cite v2.3 instead of v1.0.

---

**Prior version:** [v2.2 (2026-04-02)](https://doi.org/10.5281/zenodo.19483999) — added 29 sub-techniques.\
**Originating version:** [v1.0 (2026-03-26)](https://doi.org/10.5281/zenodo.19223924) — 9 tactics, 20 techniques, derived from the Agents of Chaos study.
