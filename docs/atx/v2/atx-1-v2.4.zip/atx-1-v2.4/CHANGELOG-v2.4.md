# 2026-05-29 — ATX-1 v2.4: Termination Poisoning (T6003) Added

**Date:** 2026-05-29\
**Type:** Version release\
**Status:** Draft — pending review and deposit\
**Tag:** `atx-1-v2.4` (pending)\
**DOI:** Pending Zenodo + IEEE DataPort deposit

---

## Summary

ATX-1 v2.4 adds one new technique — **T6003 Poison Termination Judgment** — under tactic **TA006 (Abuse Resource Allocation)**, with ten sub-techniques (T6003.001–T6003.010), one per strategy defined by Xu et al. in "LoopTrap: Termination Poisoning Attacks on LLM Agents" (arXiv:2605.05846, May 2026).

Termination Poisoning is an agent-vs-environment attack: an adversary embeds manipulative content in untrusted retrieved context (web pages, documents, tool/API responses, retrieved memory, federated or shared skills) that distorts the agent's termination judgment, causing it to treat an already-complete task as incomplete and continue executing without bound. It targets the progress-evaluation / stopping decision in the agentic control loop — distinct from indirect prompt injection (which corrupts action selection) and from model-level resource-exhaustion ("sponge") attacks (which operate on the forward pass and are ATLAS-adjacent).

This addition was surfaced via author outreach. The LoopTrap authors (Huiyu Xu, on behalf of the team) endorsed inclusion, the proposed mapping, and the naming conventions on 2026-05-22. See [docs/outreach/2026-05-looptrap-termination-poisoning.md](../docs/outreach/2026-05-looptrap-termination-poisoning.md).

---

### Added

- **T6003 — Poison Termination Judgment** (tactic TA006). Root cause: RC4 (Prompt Injection Is Structural) + RC2 (No Self-Model). OWASP: LLM01, LLM10. Constitutional article: Bounded Execution.
- **T6003.001–T6003.010** — ten sub-techniques mapped to the ten LoopTrap strategies:

  | Sub-technique | LoopTrap strategy |
  |---------------|-------------------|
  | T6003.001 Shift the Completion Target | Expanding Horizon |
  | T6003.002 Inject Open-Ended Subgoals | Incremental Milestone |
  | T6003.003 Assert Asymptotic Incompletion | Diminishing Returns |
  | T6003.004 Fabricate Authority Directives | Authority Override |
  | T6003.005 Invoke Sunk-Cost Framing | Sunk Cost Trap |
  | T6003.006 Appeal to Expert Norms | Social Proof |
  | T6003.007 Force Recursive Verification | Recursive Decomposition |
  | T6003.008 Impose Circular Prerequisites | Dependency Chain |
  | T6003.009 Reward Continued Execution | Positive Reinforcement |
  | T6003.010 Introduce Fabricated Scoring | Gamification Trap |

- **Reference [38]** added to `REFERENCES.md` (LoopTrap, Xu et al.).
- **Outreach record** added at `docs/outreach/2026-05-looptrap-termination-poisoning.md`.

### Mitigation mapping

The AEGIS mitigation for T6003 names **AGP Progress-Signal Verification** — an independent, sandboxed module that validates the agent's self-assessed progress against objective completion criteria derived outside its context window (a "shadow" progress model immune to context injection) — paired with **AGP Instruction Provenance** (provenance-aware context processing with differential weighting of untrusted content on termination decisions), and **AGP Resource Budgets** / **AGP Loop Detection** as backstops. These correspond directly to the defenses proposed by Xu et al. and independently validate AEGIS's out-of-band, model-agnostic enforcement thesis.

> **Mechanism-name note (resolved):** `AGP Progress-Signal Verification` is newly coined for this entry. There is no external AGP-1 mechanism registry to reconcile against — the `agp_mechanism` field is an ATX-1-internal descriptive label (the existing ~50 labels appear only in ATX-1 artifacts, never in the AGP-1 protocol spec, and are mostly unique per technique). The name is retained: it follows the established convention and mirrors the "Progress Signal Verification" defense term used by Xu et al.

### Metrics

- **Tactics:** 10 (unchanged)
- **Techniques:** 30 parent (was 29) + 39 sub-techniques (was 29) = **69 total entries** (was 58)
- **Root causes:** 5 (unchanged)
- **Schema:** unchanged (`atx-technique.schema.json` schema_version 2.3; T6003.* validate as-is)
- **STIX objects:** 228 (was 204) — +11 attack-patterns, +1 course-of-action (M030), +1 `uses`, +1 `mitigates`, +10 `subtechnique-of` relationships

### Compatibility

- Purely additive. No existing tactic, technique, sub-technique, root cause, or mitigation was renamed, moved, or removed relative to v2.3.
- v2.3 consumers are forward-compatible; the new technique appears as additional entries.
- Reverse mapping documented in `docs/atx/v2/data/atx-1-version-mapping.json` (`v2.4_changes`).

### Files changed

- `docs/atx/v2/data/atx-1-techniques.json` (T6003 + 10 sub-techniques added)
- `docs/atx/v2/atx-meta.json` (version 2.3.0 → 2.4.0; date; counts 58 → 69; description)
- `docs/atx/v2/data/atx-1-version-mapping.json` (`v2.4_changes` block + T6003 mapping)
- `docs/atx/v2/stix/atx-1-bundle.json` (+24 objects → 228; via `scripts/update-stix-v24.py`)
- `docs/atx/v2/data/atx-1-navigator-layer.json` (+11 entries → 69; via `scripts/update-navigator-v24.py`)
- `docs/atx/v2/data/atx-1-atm1-mapping.json` (+1 parent mapping → 26; via `scripts/update-atm1-v24.py`)
- `docs/atx/v2/data/atx-1-regulatory-crossref.json` (+11 entries → 69; via `scripts/update-regulatory-v24.py`)
- `REFERENCES.md` (reference [38])
- `docs/outreach/2026-05-looptrap-termination-poisoning.md` (new) + `docs/outreach/README.md` (log)
- `docs/atx/ATX-1_TECHNIQUE_TAXONOMY.md` (full v1→v2.4 migration of the human-readable doc; via `scripts/migrate-taxonomy-doc-v24.py`)
- `.cspell.json` (author names / domain terms)
- `scripts/update-{stix,navigator,atm1,regulatory}-v24.py`, `scripts/migrate-taxonomy-doc-v24.py` (one-shot v2.4 updaters)
- `site/public/atx-1/*` (regenerated build outputs via `npm run sync-atx`)
- `changelog/2026-05-29-atx1-v2.4.md` (this file) + `changelog/INDEX.md`

> **Note on the taxonomy doc:** `docs/atx/ATX-1_TECHNIQUE_TAXONOMY.md` was still on the pre-v2.0 tactic/technique numbering (e.g. TA006 "Governance State Corruption", T2001 "Irreversible Collateral Action") despite a v2.3 header — it had never been migrated through the v2.0 RFC-0012 normalization. v2.4 regenerates its §4 Tactic Taxonomy, §5 Technique Catalog, §6 Mitigation Mapping, and §7 OWASP Cross-Reference from the canonical v2 data, and adds a LoopTrap row to the §8 evidence hierarchy. The data-driven catalog now reflects the canonical 30 techniques + 39 sub-techniques; the per-technique prose is generated, so narrative case-study detail (present in the old v1 entries) is a candidate for later enrichment.

### Deferred

- **Behavioral vulnerability dimensions.** The four LoopTrap dimensions (phase compliance, authority compliance, recursive susceptibility, verification tendency) are defender-side measurement constructs rather than attack techniques. Pairing them with T6003 is deferred to the authors' forthcoming termination-layer robustness benchmark (behavioral persistence, recovery latency, cross-agent transferability), which operationalizes them — that benchmark will be the empirical anchor when they are added.

### Pending follow-ups (post-merge)

- Zenodo deposit (new version of existing record series) + IEEE DataPort deposit; update ecosystem CLAUDE.md identifier registry once the v2.4 DOI mints.

---

**Prior version:** [v2.3 (2026-04-24)](2026-04-24-atx1-v2.3.md) — severity field removed for MITRE alignment.\
**Source:** H. Xu et al., "LoopTrap: Termination Poisoning Attacks on LLM Agents," arXiv:2605.05846, May 2026.
