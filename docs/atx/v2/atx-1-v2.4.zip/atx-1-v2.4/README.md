# ATX-1: AEGIS Threat Matrix — Adversarial Knowledge Base for Agentic AI

This bundle contains the ATX-1 technique taxonomy, a structured adversarial knowledge base for agentic AI actor behavior.

**Current version:** v2.4 (2026-05-29) — 10 tactics, 30 techniques, 39 sub-techniques, 5 root causes, 30 mitigations\
**Dataset DOI:** [10.21227/edxj-ka42](https://doi.org/10.21227/edxj-ka42) (IEEE DataPort)\
**Zenodo (auto-minted repo snapshot):** [10.5281/zenodo.19162184](https://doi.org/10.5281/zenodo.19162184) — concept DOI, always resolves to the latest aegis-governance snapshot (the v2.4-bearing snapshot is `10.5281/zenodo.20171712`, v26.5.29.2)

**v2.4 changes:** Adds one new technique, **T6003 Poison Termination Judgment**, under
tactic TA006 (Abuse Resource Allocation), with ten sub-techniques (T6003.001–T6003.010),
one per strategy from Xu et al., "LoopTrap: Termination Poisoning Attacks on LLM Agents"
(arXiv:2605.05846, May 2026). The addition is purely additive — no existing tactic,
technique, sub-technique, root cause, or mitigation was renamed, moved, or removed
relative to v2.3. Inclusion and the proposed mapping were endorsed by the LoopTrap
authors via direct outreach (2026-05-22). See [CHANGELOG-v2.4.md](CHANGELOG-v2.4.md).

**Previous dataset versions (IEEE DataPort, frozen at published DOIs):**

- v2.3: [10.21227/jr43-0571](https://dx.doi.org/10.21227/jr43-0571) (2026-04-24) — journal-cited canonical (IEEE Data Descriptions DATA-00033-2026)
- v2.2: [10.21227/7c9p-6150](https://dx.doi.org/10.21227/7c9p-6150) (2026-04-09)
- v2.1: [10.21227/015v-9641](https://dx.doi.org/10.21227/015v-9641) (2026-03-30)
- v1.0: [10.21227/f87b-1d57](https://dx.doi.org/10.21227/f87b-1d57) (2026-03-25) — series root

The Zenodo DOIs (`10.5281/zenodo.*`) for ATX-1 are **auto-minted aegis-governance
repo snapshots**, not standalone dataset records — versioned under concept DOI
[10.5281/zenodo.19162184](https://doi.org/10.5281/zenodo.19162184). Cite the IEEE
DataPort DOIs above for the dataset itself.

## Contents

- [ATX-1_TECHNIQUE_TAXONOMY.md](ATX-1_TECHNIQUE_TAXONOMY.md) — Full technique taxonomy document (human-readable)
- [CHANGELOG-v2.4.md](CHANGELOG-v2.4.md) — v2.4 release notes
- [atx-meta.json](atx-meta.json) — Release metadata and artifact manifest
- [figures/atx-1-threat-matrix-v2.4.pdf](figures/atx-1-threat-matrix-v2.4.pdf) / [.svg](figures/atx-1-threat-matrix-v2.4.svg) — Threat-matrix figure (vector)

### Machine-Readable Formats

- [stix/atx-1-bundle.json](stix/atx-1-bundle.json) — Complete STIX 2.1 Bundle (228 objects)
- [schema/atx-technique.schema.json](schema/atx-technique.schema.json) — JSON Schema for ATX-1 technique definitions
- [data/atx-1-techniques.json](data/atx-1-techniques.json) — All 30 techniques + 39 sub-techniques as structured JSON
- [data/atx-1-regulatory-crossref.json](data/atx-1-regulatory-crossref.json) — Regulatory cross-reference matrix
- [data/atx-1-navigator-layer.json](data/atx-1-navigator-layer.json) — ATT&CK Navigator layer (v4.5)
- [data/atx-1-version-mapping.json](data/atx-1-version-mapping.json) — Version mapping (v1.0 → v2.4)
- [data/atx-1-atm1-mapping.json](data/atx-1-atm1-mapping.json) — ATX-1 ↔ ATM-1 mapping
- [data/atx-1-validation-aegis-core.json](data/atx-1-validation-aegis-core.json) — aegis-core red/blue team validation results
- [acf/acf-1-bundle.json](acf/acf-1-bundle.json) — AEGIS Counterfactual Framework bundle

## What Is ATX-1?

ATX-1 (AEGIS Threat Matrix — Agentic Exploitation and Governance Intelligence Schema) fills the gap between two existing MITRE frameworks:

- **ATT&CK** catalogs how human adversaries attack computer systems
- **ATLAS** catalogs how adversaries attack AI/ML systems
- **ATX-1** catalogs how AI agents act outside their governance boundaries

ATX-1 addresses the scenario where the AI agent itself is the threat source — not through compromise or malicious intent, but through capability without governance constraint.

## Structure

The taxonomy defines:

- **5 structural root causes** (RC1-RC5)
- **10 tactics** (TA001-TA010)
- **30 techniques** (T1001-T10004) + 39 sub-techniques
- **30 mitigations** (M001-M030) mapped to AEGIS constitutional articles and AGP mechanisms
- **Cross-references** to OWASP Top 10 for LLM Applications, NIST AI RMF, and EU AI Act

ATX-1 models three dimensions of governance failure:

- **Constraint failure** — the agent violates defined policy or scope
- **Observability failure** — the governance layer cannot observe the agent's actions
- **Interpretation failure** — the governance layer observes and permits the action, but misinterprets its semantic effect

## Machine-Readable Format Guide

### STIX 2.1 Bundle

The `stix/atx-1-bundle.json` file is a complete [STIX 2.1](https://docs.oasis-open.org/cti/stix/v2.1/stix-v2.1.html) Bundle containing 228 objects:

- **1 Identity** — AEGIS Initiative (creator)
- **10 x-mitre-tactic objects** — One per ATX-1 tactic (TA001-TA010)
- **69 attack-pattern objects** — One per technique and sub-technique, each with kill chain phases, external references, and OWASP mappings
- **30 course-of-action objects** — One per mitigation (M001-M030), each referencing constitutional articles and AGP mechanisms
- **118 relationship objects** — Tactic-to-technique (uses), mitigation-to-technique (mitigates), sub-technique-of, and technique-to-OWASP (related-to) relationships

**Consuming the STIX bundle:**

```python
# Using the stix2 Python library
from stix2 import parse

with open("stix/atx-1-bundle.json") as f:
    bundle = parse(f.read(), allow_custom=True)

# List all attack patterns
for obj in bundle.objects:
    if obj.type == "attack-pattern":
        print(f"{obj.external_references[0].external_id}: {obj.name}")
```

```bash
# Using jq to extract technique IDs and names
jq '.objects[] | select(.type == "attack-pattern") | {id: .external_references[0].external_id, name: .name}' stix/atx-1-bundle.json
```

### JSON Schema

The `schema/atx-technique.schema.json` file defines the structure for ATX-1 technique objects. Use it to validate technique definitions:

```bash
# Using ajv-cli
ajv validate -s schema/atx-technique.schema.json -d 'data/atx-1-techniques.json#/0'
```

### Technique Data

The `data/atx-1-techniques.json` file contains all 30 techniques and 39 sub-techniques as a flat JSON array. Each entry includes:

- Technique ID, name, tactic, and description
- Structural root cause(s)
- Case study references (Agents of Chaos, LoopTrap, and/or RFC-0006 adversarial testing)
- OWASP LLM Top 10 mappings
- AEGIS mitigation (constitutional article, AGP mechanism, description)

### Regulatory Cross-Reference

The `data/atx-1-regulatory-crossref.json` maps each technique to:

- **NIST AI RMF** functions (Govern, Map, Measure, Manage) with specific subcategory references
- **EU AI Act** articles with descriptions of relevant requirements
- **OWASP LLM Top 10** categories
- **ATM-1 threat scenarios** describing how the technique manifests

## Empirical Foundation

ATX-1 distinguishes between primary empirical evidence (grounds individual techniques) and corroborating research (validates the threat model independently). See the [Technique Taxonomy](ATX-1_TECHNIQUE_TAXONOMY.md) §8 for the full evidence hierarchy and technique acceptance criteria.

### Primary Empirical Evidence (Tier 1)

1. **Agents of Chaos** (Shapira et al., arXiv:2602.20021, 2026) — 11 failure modes across live agentic AI deployments. Grounds techniques T1001-T9002. The ATX-1 equivalent of MITRE's Fort Meade eXperiment (FMX).
2. **RFC-0006 Adversarial Testing** (AEGIS Initiative, 2026-03-26) — 5 rounds of white-box adversarial testing against the AEGIS Claude Code governance plugin. Grounds TA010 techniques T10001-T10004.
3. **LoopTrap: Termination Poisoning** (Xu et al., arXiv:2605.05846, 2026) — termination-poisoning attacks demonstrating 3.57× average step amplification (peak 25×) across 8 LLM agents over 60 GAIA tasks. Grounds T6003 and its ten sub-techniques (added in v2.4 via author outreach; mapping endorsed 2026-05-22).
4. **aegis-core Red/Blue Team Validation** (AEGIS Initiative, 2026-03-30) — adversarial red/blue team testing against the Python reference implementation. See [data/atx-1-validation-aegis-core.json](data/atx-1-validation-aegis-core.json). (Validation predates the v2.4 T6003 addition; T6003 is grounded by the LoopTrap study above.)

### Corroborating Research (Tier 2)

SAGA (Syros, NDSS 2026), MI9 (Wang, 2025), Governance-as-a-Service (Gaurav, 2025), Agentic AI & Cybersecurity Survey (2026), POLYNIX (Arunachalam, IEEE CCNC 2026), and the 2025 AI Agent Index (Chan, 2025) independently validate the threat model and architectural approach. See the source repository's `REFERENCES.md` for full citations.

## Live Data Endpoints

All ATX-1 data is served at <https://aegis-governance.com/atx-1/>:

- <https://aegis-governance.com/atx-1/index.json> — Dataset index
- <https://aegis-governance.com/atx-1/techniques.json> — Technique database
- <https://aegis-governance.com/atx-1/stix-bundle.json> — STIX 2.1 bundle
- <https://aegis-governance.com/atx-1/regulatory-crossref.json> — Regulatory mappings
- <https://aegis-governance.com/atx-1/navigator-layer.json> — ATT&CK Navigator layer

## Source & License

- **Source repository:** <https://github.com/aegis-initiative/aegis-governance> under `docs/atx/v2/`
- **License:** Apache License 2.0 (data and code in this bundle)
- **Taxonomy text:** CC-BY-SA-4.0
